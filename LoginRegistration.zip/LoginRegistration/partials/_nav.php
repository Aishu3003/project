<?php
session_start();
if(isset($_SESSION['loggedin'])&& $_SESSION['loggedin']!=true){
  $loggedin=true;
} 
else{
  $loggedin=false;
}
 echo '<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="/LoginRegistration">iSecure</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/LoginRegistration/login.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/LoginRegistration/login.php">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="/LoginRegistration/welcome.php">welcome</a>
        </li>';
        if(!$loggedin){
      echo'
        <li class="nav-item">
          <a class="nav-link" href="/LoginRegistration/signup.php">Signup</a>
        </li>';
        } 
      if($loggedin){
        echo'<li class="nav-item">
          <a class="nav-link" href="/LoginRegistration/logout.php">Logout</a>
        </li>';
      }

    echo '</ul> 
      <form class="form-inline" role="search">
        <input class="form-control" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>

  </div>
</nav>';
?>