<?php 
$showAlert=false;
$showError=false;
if($_SERVER['REQUEST_METHOD']=='POST'){ 
   include 'partials/dbconnect.php';
   $username=$_POST["username"];
   $password=$_POST["password"];
   $cpassword=$_POST["cpassword"];
   $exists=false;
   $existsql="select * from `users` where username='$username'";
    $result=mysqli_query($conn,$existsql);
    $numExistRows=mysqli_num_rows($result);
    if($numExistRows>0){
      $showError=" Username Already Exists";
    }
    else{
      $exists=false;
      if($password==$cpassword){
        $sql="INSERT INTO `users` ( `username`, `password`, `dt`) VALUES ('$username','$password',current_timestamp())";
        $result=mysqli_query($conn,$sql);
        if($result){
          $showAlert=true;
        }    
      }
      else{
      $showError=" Passwords do not match";
      }
  
   }
  }
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.rtl.min.css" integrity="sha384-dc2NSrAXbAkjrdm9IYrX10fQq9SDG6Vjz7nQVKdKcJl3pC+k37e7qJR5MVSCS+wR" crossorigin="anonymous">

    <title>Signup</title>
  </head>
  <body>
    <?php require 'partials/_nav.php' ?>
    <?php 
    if($showAlert){
    echo'
    <div class="alert alert-success alert-dismissible fade show" role="alert"> 
  <strong>Success!</strong> Your account is now created and you can login
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>'
;}
  if($showError){
    echo'
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
  <strong>Error!</strong>'.$showError.'
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
  </div>
';
    }
?>

  <div class="container my-4">
      <h1 class="text-center">Signup to our website</h1>

  <form action="./signup.php" method="post">
  <div class="form-group col-md-6">
    <label for="username">Username</label>
    <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp">
  </div>

  <div class="form-group col-md-6">
    <label for="password">Password</label>
    <input type="password" name="password" id="password" class="form-control">
  </div>

  <div class="form-group col-md-6">
    <label for="cpassword">Confirm Password</label>
    <input type="password" id="cpassword" name="cpassword" class="form-control">
    <small id="emailHelp" class="form-text text-muted">Make sure to type same password</small>
  </div>

  <button type="submit" class="btn btn-primary">SignUp</button>
  </form>
  </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

    
  </body>
</html>